package com.liquid.browser

import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.content.Intent
import android.view.View
import android.view.animation.DecelerateInterpolator
import android.view.animation.OvershootInterpolator
import android.webkit.CookieManager
import android.webkit.WebStorage
import android.widget.LinearLayout
import android.widget.Toast

// ---------------------------------------------------------------- sheet core

fun MainActivity.showSheet(title: String, items: List<SheetItem>) {
    sheetTitle.text = title
    adapter.items = items
    val maxH = (resources.displayMetrics.heightPixels * 0.6f).toInt()
    val want = items.size * dp(56) + dp(12)
    (sheetList.layoutParams as LinearLayout.LayoutParams).apply {
        height = minOf(want, maxH); sheetList.layoutParams = this
    }
    if (sheet.visibility != View.VISIBLE) {
        scrim.alpha = 0f
        scrim.visibility = View.VISIBLE
        scrim.animate().alpha(1f).setDuration(200).start()
        sheet.visibility = View.VISIBLE
        sheet.translationY = dp(420).toFloat()
        sheet.animate().translationY(0f).setDuration(380)
            .setInterpolator(OvershootInterpolator(0.9f)).start()
    }
}

fun MainActivity.hideSheet() {
    if (sheet.visibility != View.VISIBLE) return
    scrim.animate().alpha(0f).setDuration(160).withEndAction { scrim.visibility = View.GONE }.start()
    sheet.animate().translationY(sheet.height.toFloat()).setDuration(220)
        .setInterpolator(DecelerateInterpolator())
        .withEndAction { sheet.visibility = View.GONE }.start()
}

private fun MainActivity.toast(s: String) = Toast.makeText(this, s, Toast.LENGTH_SHORT).show()
private fun onOff(b: Boolean) = if (b) "ON" else "OFF"

// ---------------------------------------------------------------- tabs

fun MainActivity.showTabs() {
    val items = mutableListOf<SheetItem>()
    items.add(SheetItem("+  New tab") { hideSheet(); newTab(); urlField.requestFocus() })
    tabs.forEachIndexed { i, t ->
        val title = t.title.ifBlank { Utils.hostOf(t.url).ifBlank { "New tab" } }
        items.add(
            SheetItem(
                title = title,
                sub = Utils.prettyUrl(t.url),
                highlight = i == current,
                onRemove = { closeTab(i); if (sheet.visibility == View.VISIBLE) showTabs() },
                onClick = { hideSheet(); switchTo(i) }
            )
        )
    }
    if (tabs.size > 1) {
        items.add(SheetItem("Close other tabs") {
            val keep = curTab
            tabs.filter { it !== keep }.forEach { it.webView?.destroy() }
            tabs.removeAll { it !== keep }
            current = 0
            hideSheet(); updateUi()
        })
    }
    showSheet("${tabs.size} tab${if (tabs.size == 1) "" else "s"}", items)
}

// ---------------------------------------------------------------- bookmarks & history

fun MainActivity.toggleBookmark() {
    val url = curWeb?.url ?: return
    if (url == "about:blank") return
    val added = store.toggleBookmark(curTab?.title.orEmpty(), url)
    toast(if (added) "Bookmarked" else "Bookmark removed")
}

fun MainActivity.showBookmarks() {
    val list = store.bookmarks()
    val items = list.map { e ->
        SheetItem(e.title, Utils.prettyUrl(e.url),
            onRemove = { store.removeBookmark(e.url); showBookmarks() },
            onClick = { hideSheet(); go(e.url) })
    }
    showSheet(if (items.isEmpty()) "No bookmarks yet" else "Bookmarks", items)
}

fun MainActivity.showHistory() {
    val list = store.history()
    val items = list.map { e ->
        SheetItem(e.title, Utils.prettyUrl(e.url),
            onRemove = { store.removeHistory(e.url); showHistory() },
            onClick = { hideSheet(); go(e.url) })
    }.toMutableList()
    if (items.isNotEmpty()) items.add(SheetItem("Clear history") {
        store.clearHistory(); showHistory()
    })
    showSheet(if (list.isEmpty()) "No history" else "History", items)
}

// ---------------------------------------------------------------- find in page

fun MainActivity.openFind() {
    hideSheet()
    findBar.visibility = View.VISIBLE
    findField.requestFocus()
    (getSystemService(Context.INPUT_METHOD_SERVICE) as android.view.inputmethod.InputMethodManager)
        .showSoftInput(findField, 0)
}

fun MainActivity.closeFind() {
    if (findBar.visibility != View.VISIBLE) return
    findBar.visibility = View.GONE
    curWeb?.clearMatches()
    findField.setText("")
    findCount.text = ""
    hideKeyboard(findField)
}

fun MainActivity.findNext(forward: Boolean) { curWeb?.findNext(forward) }

// ---------------------------------------------------------------- long-press menu

fun MainActivity.showLinkMenu(url: String, isImage: Boolean) {
    val items = mutableListOf<SheetItem>()
    items.add(SheetItem("Open in new tab") { hideSheet(); newTab(url, switch = false) })
    items.add(SheetItem("Copy link") {
        (getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager)
            .setPrimaryClip(ClipData.newPlainText("url", url))
        hideSheet(); toast("Copied")
    })
    items.add(SheetItem("Share") { hideSheet(); shareText(url) })
    if (isImage) items.add(SheetItem("Download image") {
        hideSheet(); download(url, null, null, null)
    })
    showSheet(Utils.hostOf(url).ifBlank { "Link" }, items)
}

fun MainActivity.shareText(text: String) {
    startActivity(
        Intent.createChooser(
            Intent(Intent.ACTION_SEND).setType("text/plain").putExtra(Intent.EXTRA_TEXT, text),
            "Share"
        )
    )
}

// ---------------------------------------------------------------- main menu

fun MainActivity.showMenu() {
    val url = curWeb?.url
    val marked = url != null && store.isBookmarked(url)
    val engine = Utils.ENGINES[store.searchEngine.coerceIn(0, Utils.ENGINES.lastIndex)].first

    val items = listOf(
        SheetItem("New tab") { hideSheet(); newTab(); urlField.requestFocus() },
        SheetItem(if (marked) "Remove bookmark" else "Bookmark this page") {
            hideSheet(); toggleBookmark()
        },
        SheetItem("Bookmarks") { showBookmarks() },
        SheetItem("History") { showHistory() },
        SheetItem("Find in page") { openFind() },
        SheetItem("Share page") { hideSheet(); url?.let { shareText(it) } },
        SheetItem("Desktop site: ${onOff(store.desktopMode)}") {
            store.desktopMode = !store.desktopMode; hideSheet(); applyPrefsToAll()
        },
        SheetItem("Dark pages: ${onOff(store.forceDark)}") {
            store.forceDark = !store.forceDark; hideSheet(); applyPrefsToAll()
        },
        SheetItem("Block ads & trackers: ${onOff(store.blockAds)}") {
            store.blockAds = !store.blockAds; hideSheet(); curWeb?.reload()
        },
        SheetItem("Data saver (no images): ${onOff(store.dataSaver)}") {
            store.dataSaver = !store.dataSaver; hideSheet(); applyPrefsToAll()
        },
        SheetItem("Search engine: $engine") {
            store.searchEngine = (store.searchEngine + 1) % Utils.ENGINES.size
            showMenu()
        },
        SheetItem("Free up memory") {
            discardBackgroundTabs(); curWeb?.clearCache(false)
            hideSheet(); toast("Memory freed")
        },
        SheetItem("Clear cookies & cache") {
            CookieManager.getInstance().removeAllCookies(null)
            WebStorage.getInstance().deleteAllData()
            tabs.forEach { it.webView?.clearCache(true) }
            hideSheet(); toast("Cleared")
        },
        SheetItem(
            "Shortcuts",
            "Ctrl+T new  Ctrl+W close  Ctrl+L address  Ctrl+F find  Ctrl+R reload  " +
                "Ctrl+D bookmark  Ctrl+H history  Ctrl+Tab switch  Alt+←/→ back/forward"
        ) { }
    )
    showSheet("Menu", items)
}
