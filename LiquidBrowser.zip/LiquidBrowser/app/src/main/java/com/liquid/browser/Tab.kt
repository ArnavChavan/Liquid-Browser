package com.liquid.browser

import android.webkit.WebView

/**
 * One browser tab. [webView] is null when the tab has been "discarded" to free RAM;
 * it is recreated and reloaded from [url] the next time the tab is opened.
 */
class Tab(var url: String, var title: String = "") {
    var webView: WebView? = null
    var state: android.os.Bundle? = null   // scroll position / history saved when discarded
    var lastUsed: Long = System.currentTimeMillis()
}
