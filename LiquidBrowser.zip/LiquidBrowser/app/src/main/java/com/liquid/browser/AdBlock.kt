package com.liquid.browser

/**
 * Lightweight host-based ad/tracker blocker.
 * Blocking requests saves data, battery, CPU and RAM, which matters most on low-end phones.
 * Extend [HOSTS] with more entries any time.
 */
object AdBlock {
    private val HOSTS = hashSetOf(
        "doubleclick.net", "googlesyndication.com", "googleadservices.com",
        "adservice.google.com", "google-analytics.com", "googletagmanager.com",
        "googletagservices.com", "adnxs.com", "adsrvr.org", "taboola.com",
        "outbrain.com", "criteo.com", "criteo.net", "pubmatic.com", "rubiconproject.com",
        "openx.net", "casalemedia.com", "scorecardresearch.com", "quantserve.com",
        "moatads.com", "adform.net", "amazon-adsystem.com", "facebook.net",
        "hotjar.com", "mixpanel.com", "segment.io", "popads.net", "propellerads.com",
        "exoclick.com", "juicyads.com", "adcolony.com", "unityads.unity3d.com",
        "ads.pubmatic.com", "smartadserver.com", "mgid.com", "revcontent.com"
    )

    fun isBlocked(host: String?): Boolean {
        if (host.isNullOrEmpty()) return false
        var h: String = host.lowercase()
        while (true) {
            if (HOSTS.contains(h)) return true
            val dot = h.indexOf('.')
            if (dot < 0 || h.indexOf('.', dot + 1) < 0) return false
            h = h.substring(dot + 1)
        }
    }
}
