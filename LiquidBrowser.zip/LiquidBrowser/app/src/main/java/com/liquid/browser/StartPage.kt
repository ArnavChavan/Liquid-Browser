package com.liquid.browser

/** Built-in start page: tiny static HTML, follows system light/dark, zero network use. */
object StartPage {
    private val LINKS = listOf(
        "Google" to "https://www.google.com",
        "YouTube" to "https://m.youtube.com",
        "Wikipedia" to "https://www.wikipedia.org",
        "GitHub" to "https://github.com",
        "Reddit" to "https://www.reddit.com",
        "News" to "https://news.google.com",
        "Maps" to "https://maps.google.com",
        "Weather" to "https://weather.com"
    )

    fun html(): String {
        val tiles = LINKS.joinToString("") { (n, u) ->
            "<a class=t href=\"$u\"><span>${n.first()}</span>$n</a>"
        }
        return """
<!doctype html><html><head><meta charset=utf-8>
<meta name=viewport content="width=device-width,initial-scale=1">
<style>
:root{--bg:#f2f4f8;--fg:#14181f;--card:#fff;--acc:#4f7cff}
@media(prefers-color-scheme:dark){:root{--bg:#0e1116;--fg:#f1f4fa;--card:#1c2230;--acc:#7c9cff}}
body{margin:0;padding:64px 20px 140px;background:var(--bg);color:var(--fg);
font-family:sans-serif;text-align:center}
h1{font-weight:600;font-size:26px;margin:0 0 4px}
p{opacity:.6;margin:0 0 32px;font-size:14px}
.g{display:grid;grid-template-columns:repeat(4,1fr);gap:14px;max-width:420px;margin:auto}
.t{display:flex;flex-direction:column;align-items:center;gap:8px;font-size:12px;
color:var(--fg);text-decoration:none}
.t span{width:56px;height:56px;border-radius:22px;background:var(--card);color:var(--acc);
display:flex;align-items:center;justify-content:center;font-size:22px;font-weight:700;
box-shadow:0 2px 10px rgba(0,0,0,.12)}
.t:active span{transform:scale(.9)}
</style></head><body>
<h1>Liquid Browser</h1><p>Fast. Light. Private.</p>
<div class=g>$tiles</div></body></html>
""".trimIndent()
    }
}
