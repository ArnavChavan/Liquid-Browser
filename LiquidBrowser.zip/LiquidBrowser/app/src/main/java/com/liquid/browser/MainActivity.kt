package com.liquid.browser

import android.Manifest
import android.annotation.SuppressLint
import android.app.DownloadManager
import android.content.ComponentCallbacks2
import android.content.Intent
import android.content.pm.PackageManager
import android.content.res.Configuration
import android.graphics.Bitmap
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.os.Environment
import android.view.KeyEvent
import android.view.MotionEvent
import android.view.View
import android.view.ViewGroup
import android.view.animation.DecelerateInterpolator
import android.view.animation.OvershootInterpolator
import android.view.inputmethod.EditorInfo
import android.view.inputmethod.InputMethodManager
import android.webkit.*
import android.widget.EditText
import android.widget.FrameLayout
import android.widget.ImageButton
import android.widget.LinearLayout
import android.widget.ListView
import android.widget.TextView
import android.widget.Toast
import androidx.activity.OnBackPressedCallback
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.ViewCompat
import androidx.core.view.WindowCompat
import androidx.core.view.WindowInsetsCompat
import androidx.swiperefreshlayout.widget.SwipeRefreshLayout
import androidx.webkit.WebSettingsCompat
import androidx.webkit.WebViewFeature
import java.io.ByteArrayInputStream

class MainActivity : AppCompatActivity() {

    companion object {
        const val MAX_LIVE_TABS = 3      // only this many WebViews stay in RAM
        const val REQ_STORAGE = 77
    }

    lateinit var store: Store
    val tabs = mutableListOf<Tab>()
    var current = 0

    lateinit var root: FrameLayout
    lateinit var swipe: SwipeRefreshLayout
    lateinit var webContainer: FrameLayout
    lateinit var progress: View
    lateinit var bottomBar: LinearLayout
    lateinit var urlField: EditText
    lateinit var tabCount: TextView
    lateinit var btnBack: ImageButton
    lateinit var btnForward: ImageButton
    lateinit var findBar: LinearLayout
    lateinit var findField: EditText
    lateinit var findCount: TextView
    lateinit var scrim: View
    lateinit var sheet: LinearLayout
    lateinit var sheetTitle: TextView
    lateinit var sheetList: ListView
    lateinit var fullscreen: FrameLayout
    lateinit var adapter: SheetAdapter

    var barHidden = false
    var customView: View? = null
    var customCb: WebChromeClient.CustomViewCallback? = null
    var fileCb: ValueCallback<Array<Uri>>? = null
    var pendingDownload: (() -> Unit)? = null

    val curTab: Tab? get() = tabs.getOrNull(current)
    val curWeb: WebView? get() = curTab?.webView

    private val fileLauncher =
        registerForActivityResult(ActivityResultContracts.StartActivityForResult()) { r ->
            fileCb?.onReceiveValue(
                WebChromeClient.FileChooserParams.parseResult(r.resultCode, r.data)
            )
            fileCb = null
        }

    fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()

    fun launchFileChooser(i: Intent) = fileLauncher.launch(i)

    // ------------------------------------------------------------------ lifecycle

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        store = Store(this)
        WindowCompat.setDecorFitsSystemWindows(window, false)
        setContentView(R.layout.activity_main)
        bindViews()
        setupInsets()
        setupInput()
        setupBackHandling()

        val night = (resources.configuration.uiMode and Configuration.UI_MODE_NIGHT_MASK) ==
            Configuration.UI_MODE_NIGHT_YES
        WindowCompat.getInsetsController(window, window.decorView).apply {
            isAppearanceLightStatusBars = !night
            isAppearanceLightNavigationBars = !night
        }

        val incoming = intentUrl(intent)
        val (saved, active) = store.loadSession()
        if (saved.isNotEmpty()) {
            saved.forEach { tabs.add(Tab(it)) }
            current = active.coerceIn(0, tabs.lastIndex)
        } else {
            tabs.add(Tab(Utils.HOME))
        }
        if (incoming != null) {
            tabs.add(Tab(incoming)); current = tabs.lastIndex
        }
        switchTo(current)
        popIn()
    }

    override fun onNewIntent(intent: Intent) {
        super.onNewIntent(intent)
        intentUrl(intent)?.let { newTab(it) }
    }

    private fun intentUrl(i: Intent?): String? = when (i?.action) {
        Intent.ACTION_VIEW -> i.dataString
        Intent.ACTION_SEND -> i.getStringExtra(Intent.EXTRA_TEXT)?.let { Utils.resolve(it, store.searchEngine) }
        else -> null
    }

    override fun onPause() {
        super.onPause()
        curWeb?.onPause()
        store.saveSession(tabs.map { it.webView?.url?.takeIf { u -> u.isNotEmpty() } ?: it.url }, current)
    }

    override fun onResume() {
        super.onResume()
        curWeb?.onResume()
    }

    override fun onTrimMemory(level: Int) {
        super.onTrimMemory(level)
        // Free every background WebView when the system is short on RAM or app is hidden.
        if (level >= ComponentCallbacks2.TRIM_MEMORY_RUNNING_LOW) discardBackgroundTabs()
    }

    override fun onDestroy() {
        tabs.forEach { it.webView?.destroy(); it.webView = null }
        super.onDestroy()
    }

    // ------------------------------------------------------------------ view setup

    private fun bindViews() {
        root = findViewById(R.id.root)
        swipe = findViewById(R.id.swipe)
        webContainer = findViewById(R.id.webContainer)
        progress = findViewById(R.id.progress)
        bottomBar = findViewById(R.id.bottomBar)
        urlField = findViewById(R.id.urlField)
        tabCount = findViewById(R.id.tabCount)
        btnBack = findViewById(R.id.btnBack)
        btnForward = findViewById(R.id.btnForward)
        findBar = findViewById(R.id.findBar)
        findField = findViewById(R.id.findField)
        findCount = findViewById(R.id.findCount)
        scrim = findViewById(R.id.scrim)
        sheet = findViewById(R.id.sheet)
        sheetTitle = findViewById(R.id.sheetTitle)
        sheetList = findViewById(R.id.sheetList)
        fullscreen = findViewById(R.id.fullscreen)
        adapter = SheetAdapter(this)
        sheetList.adapter = adapter
    }

    private fun setupInsets() {
        ViewCompat.setOnApplyWindowInsetsListener(root) { _, insets ->
            val bars = insets.getInsets(WindowInsetsCompat.Type.systemBars())
            val ime = insets.getInsets(WindowInsetsCompat.Type.ime())
            val bottom = maxOf(bars.bottom, ime.bottom)
            (bottomBar.layoutParams as FrameLayout.LayoutParams).apply {
                bottomMargin = dp(12) + bottom
                bottomBar.layoutParams = this
            }
            (findBar.layoutParams as FrameLayout.LayoutParams).apply {
                topMargin = bars.top + dp(8)
                findBar.layoutParams = this
            }
            swipe.setPadding(0, bars.top, 0, 0)
            sheet.setPadding(0, dp(14), 0, bars.bottom)
            insets
        }
    }

    @SuppressLint("ClickableViewAccessibility")
    private fun setupInput() {
        swipe.setColorSchemeResources(R.color.accent)
        swipe.setOnRefreshListener { curWeb?.reload() ?: run { swipe.isRefreshing = false } }
        swipe.setOnChildScrollUpCallback { _, _ -> (curWeb?.scrollY ?: 0) > 0 }

        urlField.setOnEditorActionListener { v, id, e ->
            if (id == EditorInfo.IME_ACTION_GO ||
                (e?.keyCode == KeyEvent.KEYCODE_ENTER && e.action == KeyEvent.ACTION_DOWN)
            ) {
                go(v.text.toString()); hideKeyboard(v); v.clearFocus(); true
            } else false
        }
        urlField.setOnFocusChangeListener { _, focus ->
            if (focus) {
                val u = curTab?.webView?.url ?: curTab?.url
                urlField.setText(if (u == null || u == Utils.HOME) "" else u)
                urlField.selectAll()
                showBar()
            } else updateUi()
        }

        btnBack.setOnClickListener { curWeb?.let { if (it.canGoBack()) it.goBack() } }
        btnForward.setOnClickListener { curWeb?.let { if (it.canGoForward()) it.goForward() } }
        findViewById<ImageButton>(R.id.btnRefresh).setOnClickListener {
            curWeb?.let { if (progress.visibility == View.VISIBLE) it.stopLoading() else it.reload() }
        }
        findViewById<ImageButton>(R.id.btnTabs).setOnClickListener { showTabs() }
        findViewById<ImageButton>(R.id.btnMenu).setOnClickListener { showMenu() }
        scrim.setOnClickListener { hideSheet() }

        findField.setOnEditorActionListener { _, _, _ -> findNext(true); true }
        findField.addTextChangedListener(object : android.text.TextWatcher {
            override fun afterTextChanged(s: android.text.Editable?) {
                curWeb?.findAllAsync(s?.toString().orEmpty())
            }
            override fun beforeTextChanged(s: CharSequence?, a: Int, b: Int, c: Int) {}
            override fun onTextChanged(s: CharSequence?, a: Int, b: Int, c: Int) {}
        })
        findViewById<ImageButton>(R.id.findNext).setOnClickListener { findNext(true) }
        findViewById<ImageButton>(R.id.findPrev).setOnClickListener { findNext(false) }
        findViewById<ImageButton>(R.id.findClose).setOnClickListener { closeFind() }

        // Liquid press feel on every bar button
        listOf(
            btnBack, btnForward, findViewById<View>(R.id.btnRefresh),
            findViewById<View>(R.id.btnTabs), findViewById<View>(R.id.btnMenu)
        ).forEach { bounce(it) }
    }

    @SuppressLint("ClickableViewAccessibility")
    fun bounce(v: View) {
        v.setOnTouchListener { view, e ->
            when (e.action) {
                MotionEvent.ACTION_DOWN ->
                    view.animate().scaleX(0.82f).scaleY(0.82f).setDuration(90).start()
                MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL ->
                    view.animate().scaleX(1f).scaleY(1f).setDuration(260)
                        .setInterpolator(OvershootInterpolator(3f)).start()
            }
            false
        }
    }

    private fun popIn() {
        bottomBar.translationY = dp(140).toFloat()
        bottomBar.alpha = 0f
        bottomBar.animate().translationY(0f).alpha(1f).setDuration(450)
            .setInterpolator(OvershootInterpolator(1.0f)).start()
    }

    fun hideBar() {
        if (barHidden || urlField.hasFocus() || sheet.visibility == View.VISIBLE) return
        barHidden = true
        bottomBar.animate().translationY((bottomBar.height + dp(48)).toFloat())
            .setDuration(220).setInterpolator(DecelerateInterpolator()).start()
    }

    fun showBar() {
        if (!barHidden && bottomBar.translationY == 0f) return
        barHidden = false
        bottomBar.animate().translationY(0f).setDuration(340)
            .setInterpolator(OvershootInterpolator(1.1f)).start()
    }

    fun hideKeyboard(v: View) {
        (getSystemService(INPUT_METHOD_SERVICE) as InputMethodManager)
            .hideSoftInputFromWindow(v.windowToken, 0)
    }

    private fun setupBackHandling() {
        onBackPressedDispatcher.addCallback(this, object : OnBackPressedCallback(true) {
            override fun handleOnBackPressed() {
                when {
                    customView != null -> hideCustomView()
                    sheet.visibility == View.VISIBLE -> hideSheet()
                    findBar.visibility == View.VISIBLE -> closeFind()
                    curWeb?.canGoBack() == true -> curWeb?.goBack()
                    tabs.size > 1 -> closeTab(current)
                    else -> finish()
                }
            }
        })
    }

    // ------------------------------------------------------------------ UI state

    fun updateUi() {
        tabCount.text = tabs.size.toString()
        btnBack.alpha = if (curWeb?.canGoBack() == true) 1f else 0.35f
        btnForward.alpha = if (curWeb?.canGoForward() == true) 1f else 0.35f
        if (!urlField.hasFocus()) {
            val u = curWeb?.url ?: curTab?.url
            urlField.setText(Utils.prettyUrl(u))
        }
    }

    fun setProgress(p: Int) {
        if (p >= 100) {
            progress.animate().scaleX(1f).setDuration(120).withEndAction {
                progress.visibility = View.INVISIBLE; progress.scaleX = 0f
            }.start()
        } else {
            progress.visibility = View.VISIBLE
            progress.animate().scaleX(p / 100f).setDuration(150).start()
        }
    }

    // ------------------------------------------------------------------ tabs

    fun newTab(url: String = Utils.HOME, switch: Boolean = true) {
        tabs.add(Tab(url))
        if (switch) switchTo(tabs.lastIndex) else {
            updateUi(); Toast.makeText(this, "Opened in background", Toast.LENGTH_SHORT).show()
        }
    }

    fun switchTo(i: Int) {
        if (i !in tabs.indices) return
        closeFind()
        tabs.getOrNull(current)?.webView?.let { it.onPause(); webContainer.removeView(it) }
        current = i
        val t = tabs[i]
        t.lastUsed = System.currentTimeMillis()
        var fresh = false
        if (t.webView == null) { t.webView = createWebView(); fresh = true }
        val wv = t.webView!!
        webContainer.addView(
            wv, FrameLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT
            )
        )
        wv.onResume()
        if (fresh) {
            val st = t.state
            if (st != null) { wv.restoreState(st); t.state = null } else loadInto(wv, t.url)
        }
        trimLiveTabs()
        swipe.isRefreshing = false
        progress.visibility = View.INVISIBLE
        updateUi()
        showBar()
    }

    fun closeTab(i: Int) {
        if (i !in tabs.indices) return
        val t = tabs[i]
        val wasCurrent = i == current
        t.webView?.let { if (wasCurrent) webContainer.removeView(it); it.destroy() }
        tabs.removeAt(i)
        when {
            tabs.isEmpty() -> { current = 0; newTab() }
            wasCurrent -> switchTo(minOf(i, tabs.lastIndex))
            else -> { if (i < current) current--; updateUi() }
        }
    }

    private fun discardTab(t: Tab) {
        val wv = t.webView ?: return
        val b = Bundle()
        wv.saveState(b)
        t.state = b
        t.url = wv.url?.takeIf { it.isNotEmpty() } ?: t.url
        wv.destroy()
        t.webView = null
    }

    private fun trimLiveTabs() {
        val live = tabs.filter { it.webView != null && it !== curTab }.sortedBy { it.lastUsed }
        var extra = live.size - (MAX_LIVE_TABS - 1)
        for (t in live) { if (extra <= 0) break; discardTab(t); extra-- }
    }

    fun discardBackgroundTabs() {
        tabs.filter { it !== curTab }.forEach { discardTab(it) }
    }

    fun loadInto(wv: WebView, url: String) {
        if (url == Utils.HOME) {
            wv.loadDataWithBaseURL("about:blank", StartPage.html(), "text/html", "utf-8", null)
        } else wv.loadUrl(url)
    }

    fun go(input: String) {
        val u = Utils.resolve(input, store.searchEngine)
        val t = curTab ?: return
        t.url = u
        curWeb?.let { loadInto(it, u) }
    }

    // ------------------------------------------------------------------ keyboard shortcuts

    override fun dispatchKeyEvent(e: KeyEvent): Boolean {
        if (e.action == KeyEvent.ACTION_DOWN) {
            if (e.isCtrlPressed) {
                val handled = when (e.keyCode) {
                    KeyEvent.KEYCODE_T -> { newTab(); urlField.requestFocus(); true }
                    KeyEvent.KEYCODE_W -> { closeTab(current); true }
                    KeyEvent.KEYCODE_L -> { urlField.requestFocus(); true }
                    KeyEvent.KEYCODE_F -> { openFind(); true }
                    KeyEvent.KEYCODE_R -> { curWeb?.reload(); true }
                    KeyEvent.KEYCODE_D -> { toggleBookmark(); true }
                    KeyEvent.KEYCODE_H -> { showHistory(); true }
                    KeyEvent.KEYCODE_B -> { showBookmarks(); true }
                    KeyEvent.KEYCODE_TAB -> {
                        val n = if (e.isShiftPressed) current - 1 else current + 1
                        switchTo((n + tabs.size) % tabs.size); true
                    }
                    in KeyEvent.KEYCODE_1..KeyEvent.KEYCODE_9 -> {
                        switchTo(minOf(e.keyCode - KeyEvent.KEYCODE_1, tabs.lastIndex)); true
                    }
                    else -> false
                }
                if (handled) return true
            }
            if (e.isAltPressed) {
                when (e.keyCode) {
                    KeyEvent.KEYCODE_DPAD_LEFT -> { curWeb?.goBack(); return true }
                    KeyEvent.KEYCODE_DPAD_RIGHT -> { curWeb?.goForward(); return true }
                }
            }
            if (e.keyCode == KeyEvent.KEYCODE_F5) { curWeb?.reload(); return true }
        }
        return super.dispatchKeyEvent(e)
    }

    // ------------------------------------------------------------------ downloads & permissions

    fun download(url: String, ua: String?, disp: String?, mime: String?) {
        val job = {
            try {
                val name = URLUtil.guessFileName(url, disp, mime)
                val req = DownloadManager.Request(Uri.parse(url)).apply {
                    setMimeType(mime)
                    ua?.let { addRequestHeader("User-Agent", it) }
                    CookieManager.getInstance().getCookie(url)?.let { addRequestHeader("Cookie", it) }
                    setNotificationVisibility(
                        DownloadManager.Request.VISIBILITY_VISIBLE_NOTIFY_COMPLETED
                    )
                    setDestinationInExternalPublicDir(Environment.DIRECTORY_DOWNLOADS, name)
                }
                (getSystemService(DOWNLOAD_SERVICE) as DownloadManager).enqueue(req)
                Toast.makeText(this, "Downloading $name", Toast.LENGTH_SHORT).show()
            } catch (ex: Exception) {
                Toast.makeText(this, "Download failed", Toast.LENGTH_SHORT).show()
            }
        }
        if (Build.VERSION.SDK_INT <= 28 && checkSelfPermission(
                Manifest.permission.WRITE_EXTERNAL_STORAGE
            ) != PackageManager.PERMISSION_GRANTED
        ) {
            pendingDownload = job
            requestPermissions(arrayOf(Manifest.permission.WRITE_EXTERNAL_STORAGE), REQ_STORAGE)
        } else job()
    }

    override fun onRequestPermissionsResult(code: Int, perms: Array<out String>, res: IntArray) {
        super.onRequestPermissionsResult(code, perms, res)
        if (code == REQ_STORAGE && res.firstOrNull() == PackageManager.PERMISSION_GRANTED) {
            pendingDownload?.invoke()
        }
        pendingDownload = null
    }

    // ------------------------------------------------------------------ full-screen video

    fun showCustomView(v: View, cb: WebChromeClient.CustomViewCallback) {
        if (customView != null) { cb.onCustomViewHidden(); return }
        customView = v; customCb = cb
        fullscreen.addView(v)
        fullscreen.visibility = View.VISIBLE
        WindowCompat.getInsetsController(window, window.decorView)
            .hide(WindowInsetsCompat.Type.systemBars())
    }

    fun hideCustomView() {
        customView?.let { fullscreen.removeView(it) }
        fullscreen.visibility = View.GONE
        customView = null
        customCb?.onCustomViewHidden(); customCb = null
        WindowCompat.getInsetsController(window, window.decorView)
            .show(WindowInsetsCompat.Type.systemBars())
    }
}
