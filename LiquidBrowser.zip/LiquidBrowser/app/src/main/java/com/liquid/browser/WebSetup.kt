package com.liquid.browser

import android.annotation.SuppressLint
import android.content.ActivityNotFoundException
import android.content.Intent
import android.graphics.Bitmap
import android.net.Uri
import android.os.Build
import android.view.View
import android.webkit.*
import androidx.webkit.WebSettingsCompat
import androidx.webkit.WebViewFeature
import java.io.ByteArrayInputStream

@SuppressLint("SetJavaScriptEnabled")
fun MainActivity.applySettings(wv: WebView) {
    val s = wv.settings
    s.javaScriptEnabled = true
    s.domStorageEnabled = true
    s.setSupportZoom(true)
    s.builtInZoomControls = true
    s.displayZoomControls = false
    s.useWideViewPort = true
    s.loadWithOverviewMode = true
    s.mediaPlaybackRequiresUserGesture = true      // no autoplay = less data, less CPU
    s.allowFileAccess = false
    s.allowContentAccess = false
    s.blockNetworkImage = store.dataSaver           // Data saver: skip images
    s.userAgentString =
        if (store.desktopMode) Utils.DESKTOP_UA else WebSettings.getDefaultUserAgent(this)
    if (Build.VERSION.SDK_INT >= 26) s.safeBrowsingEnabled = true

    if (WebViewFeature.isFeatureSupported(WebViewFeature.FORCE_DARK)) {
        @Suppress("DEPRECATION")
        WebSettingsCompat.setForceDark(
            s,
            if (store.forceDark) WebSettingsCompat.FORCE_DARK_ON else WebSettingsCompat.FORCE_DARK_OFF
        )
    }
    if (WebViewFeature.isFeatureSupported(WebViewFeature.ALGORITHMIC_DARKENING)) {
        WebSettingsCompat.setAlgorithmicDarkeningAllowed(s, store.forceDark)
    }
}

/** Re-apply settings to every live tab and reload the current one. */
fun MainActivity.applyPrefsToAll() {
    tabs.forEach { t -> t.webView?.let { applySettings(it) } }
    curWeb?.reload()
}

private fun MainActivity.tabOf(view: WebView?) = tabs.firstOrNull { it.webView === view }
private fun MainActivity.isCurrent(view: WebView?) = view != null && curWeb === view

@SuppressLint("ClickableViewAccessibility")
fun MainActivity.createWebView(): WebView {
    val wv = WebView(this)
    applySettings(wv)
    CookieManager.getInstance().setAcceptThirdPartyCookies(wv, false) // privacy
    wv.overScrollMode = View.OVER_SCROLL_NEVER

    wv.setDownloadListener { url, ua, disp, mime, _ -> download(url, ua, disp, mime) }

    wv.setFindListener { active, total, _ ->
        findCount.text = if (total == 0) "0" else "${active + 1}/$total"
    }

    wv.setOnScrollChangeListener { _, _, y, _, oy ->
        val d = y - oy
        if (d > 10) hideBar() else if (d < -10 || y <= 0) showBar()
    }

    wv.setOnLongClickListener {
        val r = wv.hitTestResult
        val extra = r.extra
        when (r.type) {
            WebView.HitTestResult.SRC_ANCHOR_TYPE,
            WebView.HitTestResult.IMAGE_TYPE,
            WebView.HitTestResult.SRC_IMAGE_ANCHOR_TYPE -> {
                if (extra != null) {
                    showLinkMenu(extra, r.type != WebView.HitTestResult.SRC_ANCHOR_TYPE); true
                } else false
            }
            else -> false
        }
    }

    wv.webViewClient = object : WebViewClient() {
        override fun shouldInterceptRequest(
            view: WebView?, request: WebResourceRequest?
        ): WebResourceResponse? {
            if (store.blockAds && AdBlock.isBlocked(request?.url?.host)) {
                return WebResourceResponse("text/plain", "utf-8", ByteArrayInputStream(ByteArray(0)))
            }
            return null
        }

        override fun shouldOverrideUrlLoading(view: WebView, req: WebResourceRequest): Boolean {
            val u = req.url
            val scheme = u.scheme ?: return false
            if (scheme == "http" || scheme == "https" || scheme == "about" || scheme == "data") {
                return false
            }
            try {
                val i = if (scheme == "intent") {
                    Intent.parseUri(u.toString(), Intent.URI_INTENT_SCHEME).apply {
                        addCategory(Intent.CATEGORY_BROWSABLE); component = null; selector = null
                    }
                } else Intent(Intent.ACTION_VIEW, u)
                startActivity(i)
            } catch (_: Exception) {
            }
            return true
        }

        override fun onPageStarted(view: WebView, url: String?, favicon: Bitmap?) {
            tabOf(view)?.let { if (url != null && url != "about:blank") it.url = url }
            if (isCurrent(view)) { setProgress(5); updateUi() }
        }

        override fun onPageFinished(view: WebView, url: String?) {
            val t = tabOf(view) ?: return
            if (url != null) t.url = if (url.startsWith("data:")) t.url else url
            t.title = view.title.orEmpty()
            if (url != null && url != "about:blank" && !url.startsWith("data:")) {
                store.addHistory(t.title, url)
            }
            if (isCurrent(view)) { swipe.isRefreshing = false; setProgress(100); updateUi() }
        }

        override fun doUpdateVisitedHistory(view: WebView, url: String?, isReload: Boolean) {
            if (isCurrent(view)) updateUi()
        }

        override fun onReceivedError(
            view: WebView, req: WebResourceRequest, err: WebResourceError
        ) {
            if (!req.isForMainFrame) return
            val html = """
                <html><head><meta name=viewport content="width=device-width,initial-scale=1">
                <style>body{font-family:sans-serif;text-align:center;padding:90px 24px;
                color:#888}h2{color:#4f7cff}a{display:inline-block;margin-top:20px;
                padding:12px 28px;border-radius:24px;background:#4f7cff;color:#fff;
                text-decoration:none}</style></head><body>
                <h2>Can't open this page</h2><p>${err.description}</p>
                <a href="${req.url}">Try again</a></body></html>
            """.trimIndent()
            view.loadDataWithBaseURL(req.url.toString(), html, "text/html", "utf-8", req.url.toString())
        }
    }

    wv.webChromeClient = object : WebChromeClient() {
        override fun onProgressChanged(view: WebView, p: Int) {
            if (isCurrent(view)) setProgress(p)
        }

        override fun onReceivedTitle(view: WebView, title: String?) {
            tabOf(view)?.title = title.orEmpty()
        }

        override fun onShowCustomView(view: View, cb: CustomViewCallback) = showCustomView(view, cb)
        override fun onHideCustomView() = hideCustomView()

        override fun onShowFileChooser(
            webView: WebView, cb: ValueCallback<Array<Uri>>, params: FileChooserParams
        ): Boolean {
            fileCb?.onReceiveValue(null)
            fileCb = cb
            return try {
                launchFileChooser(params.createIntent()); true
            } catch (_: ActivityNotFoundException) {
                fileCb = null; false
            }
        }

        // Privacy by default: deny location / camera / mic requests.
        override fun onGeolocationPermissionsShowPrompt(
            origin: String?, callback: GeolocationPermissions.Callback?
        ) { callback?.invoke(origin, false, false) }

        override fun onPermissionRequest(request: PermissionRequest?) { request?.deny() }
    }
    return wv
}
