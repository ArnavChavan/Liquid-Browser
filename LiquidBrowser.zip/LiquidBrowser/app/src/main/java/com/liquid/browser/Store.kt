package com.liquid.browser

import android.content.Context
import org.json.JSONArray
import org.json.JSONObject

data class Entry(val title: String, val url: String)

/** Tiny SharedPreferences-backed storage. No database = no extra RAM or APK size. */
class Store(ctx: Context) {
    private val sp = ctx.applicationContext.getSharedPreferences("liquid", Context.MODE_PRIVATE)

    var desktopMode: Boolean
        get() = sp.getBoolean("desktop", false)
        set(v) = sp.edit().putBoolean("desktop", v).apply()

    var blockAds: Boolean
        get() = sp.getBoolean("ads", true)
        set(v) = sp.edit().putBoolean("ads", v).apply()

    /** Data saver: blocks images, great for slow networks and low RAM. */
    var dataSaver: Boolean
        get() = sp.getBoolean("saver", false)
        set(v) = sp.edit().putBoolean("saver", v).apply()

    var forceDark: Boolean
        get() = sp.getBoolean("dark", false)
        set(v) = sp.edit().putBoolean("dark", v).apply()

    var searchEngine: Int
        get() = sp.getInt("engine", 0)
        set(v) = sp.edit().putInt("engine", v).apply()

    // ---- lists ----
    private fun read(key: String): MutableList<Entry> {
        val out = mutableListOf<Entry>()
        try {
            val arr = JSONArray(sp.getString(key, "[]"))
            for (i in 0 until arr.length()) {
                val o = arr.getJSONObject(i)
                out.add(Entry(o.optString("t"), o.optString("u")))
            }
        } catch (_: Exception) {
        }
        return out
    }

    private fun write(key: String, list: List<Entry>) {
        val arr = JSONArray()
        list.forEach { arr.put(JSONObject().put("t", it.title).put("u", it.url)) }
        sp.edit().putString(key, arr.toString()).apply()
    }

    fun bookmarks() = read("bookmarks")
    fun history() = read("history")

    fun isBookmarked(url: String) = bookmarks().any { it.url == url }

    /** @return true if now bookmarked */
    fun toggleBookmark(title: String, url: String): Boolean {
        val list = bookmarks()
        val existing = list.indexOfFirst { it.url == url }
        return if (existing >= 0) {
            list.removeAt(existing); write("bookmarks", list); false
        } else {
            list.add(0, Entry(title.ifBlank { url }, url)); write("bookmarks", list); true
        }
    }

    fun removeBookmark(url: String) = write("bookmarks", bookmarks().filter { it.url != url })

    fun addHistory(title: String, url: String) {
        if (url.startsWith("about:")) return
        val list = history()
        list.removeAll { it.url == url }
        list.add(0, Entry(title.ifBlank { url }, url))
        write("history", list.take(150)) // capped: keeps memory & disk tiny
    }

    fun removeHistory(url: String) = write("history", history().filter { it.url != url })
    fun clearHistory() = sp.edit().remove("history").apply()

    // ---- session restore ----
    fun saveSession(urls: List<String>, active: Int) {
        sp.edit().putString("session", JSONArray(urls).toString()).putInt("active", active).apply()
    }

    fun loadSession(): Pair<List<String>, Int> {
        val urls = mutableListOf<String>()
        try {
            val arr = JSONArray(sp.getString("session", "[]"))
            for (i in 0 until arr.length()) urls.add(arr.getString(i))
        } catch (_: Exception) {
        }
        return urls to sp.getInt("active", 0)
    }
}
