# Liquid Browser

A lightweight Android browser built on the system WebView (Kotlin, minSdk 24 / Android 7+).
Only 3 small dependencies (appcompat, webkit, swiperefreshlayout), so the APK stays small and RAM use stays low.

## Build & run
1. Install Android Studio (Koala or newer).
2. `File > Open` and choose this `LiquidBrowser` folder. Let Gradle sync (Android Studio creates the wrapper for you).
3. Run on a device or emulator. For a release APK: `Build > Generate Signed Bundle / APK`.

## Features
**Browsing**
- Multi-tab with tab switcher, close-others, session restore
- Smart address bar: URLs or search (DuckDuckGo, Google, Bing, Brave, switch in menu)
- Bookmarks, history (capped at 150), find in page, share, open-in-new-tab, copy link
- Pull to refresh, load progress line, custom error page with retry
- Downloads (system DownloadManager), file upload, full-screen video
- Desktop site toggle, dark pages toggle
- Opens links from other apps and handles "share text to browser"

**Privacy**
- Built-in ad and tracker blocker (host list in `AdBlock.kt`, add your own)
- Third-party cookies off, camera/mic/location requests denied by default
- Safe Browsing on, one-tap clear cookies and cache

**Low-end device performance**
- Max 3 live WebViews; older tabs are discarded (state saved) and restored on demand
- All background tabs freed when the system reports memory pressure or the app is hidden
- "Free up memory" button, Data saver mode (blocks images), no autoplay media
- No database, no image-loading library, no heavy UI framework

**Keyboard shortcuts** (hardware keyboard)
Ctrl+T new tab, Ctrl+W close, Ctrl+L address bar, Ctrl+F find, Ctrl+R / F5 reload,
Ctrl+D bookmark, Ctrl+H history, Ctrl+B bookmarks, Ctrl+Tab / Ctrl+Shift+Tab switch,
Ctrl+1..9 jump to tab, Alt+Left/Right back/forward.

**Liquid UI**
- Floating glass pill bar with big curves, translucent fill and hairline highlight
- Springy overshoot animations on bar, sheets and button presses
- Bar slides away while scrolling down and returns when scrolling up
- Bottom sheets with rounded top corners; automatic light and dark theme

## Notes
- "Dark pages" uses WebView's built-in darkening; on newer Android versions it follows
  WebView support and may need the system dark theme on.
- Background blur behind the glass bar is not implemented (Android has no cheap backdrop blur);
  it uses a translucent fill instead, which is also much lighter on weak GPUs.

## Ideas for next steps
Reader mode, per-site settings, import/export bookmarks, custom filter lists,
password manager integration, incognito tabs.
